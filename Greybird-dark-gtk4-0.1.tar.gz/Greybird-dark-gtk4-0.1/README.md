# Greybird-dark GTK4

GTK4 stylesheet for Greybird-dark, built from the `gtk-4.0` SCSS sources of
[Greybird](https://github.com/shimmerproject/Greybird) (dark variant).
Greybird is © 2009–2019 Simon Steinbeiß, Satyajit Sahoo, Pasi Lallinaho, Carson Black,
Maurizio Galli, dual-licensed GPLv2+ / CC-BY-SA 3.0+ (see LICENSE.GPL, LICENSE.CC).
The fixes below were made by Claude (Anthropic).

## Install

`Greybird-dark/` is a complete GTK theme: copy it to `~/.themes/`.

- `gtk-2.0`: upstream's, unchanged.
- `gtk-3.0`: upstream's, unchanged, compiled from the SCSS with sassc (`gtk.css`, `gtk-dark.css`); the optional
  `gtk.gresource` is not built, GTK3 reads the CSS and `assets/` directly.
- `gtk-4.0`: new, see below. `gtk.css` and `gtk-dark.css` are the same file (dark in both cases).
- Xfwm4, Metacity and the other parts of Greybird-dark are not included.

## Changes to the upstream GTK4 sources

- Sass function `entry_focus-within_border` (a mangled `:focus` rename) → `entry_focus_border`. It produced invalid
  colours, so the focus and error/warning borders of entries and linked combos were dropped.
- Removed properties GTK4 does not have: `-gtk-outline-*radius`, `-GtkWidget-*`, `-GtkTreeView-*`, `-GtkScrollbar-*`.
- `-gtk-icon-effect` → `-gtk-icon-filter`.
- `-gtk-gradient(radial, …)` (scroll overshoot, needs-attention) → `radial-gradient(…)`.
- Check, radio and dash marks use the symbolic PNG only; the `image(svg, png)` fallback does not work in GTK4
  and showed no mark where the SVG loader was missing.
- `scale highlight/fill`: added a minimum size, as GTK4 rejects the negative size the `-2px` margin gave.

GTK 4.14.5 reports no CSS errors for the result (it reported 51 for the upstream CSS).

## Known gaps (same in upstream)

Touch text-selection handles and selection-mode check boxes refer to image files that upstream does not ship.

## Rebuild

`sassc -t expanded gtk-dark.scss gtk.css` in `scss/` (sassc / libsass 3.6; Dart Sass cannot compile these sources).
